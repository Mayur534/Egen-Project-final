(function() {

	angular
	.module('MainModule')
	.controller('MainController', mController);
		
	

	
		mController.$inject = ['$http']
		function mController($http) {
			var mainCtrl = this;
			
			mainCtrl.tab = 1;
		    
		    mainCtrl.selectTab = function (setTab){
		    	mainCtrl.tab = setTab;
		    };
		    mainCtrl.isSelected = function(checkTab) {
		    	return mainCtrl.tab === checkTab;
		    };
			
			
				
					$http ({
						method: 'GET',
						url: 'api/reservation/all'
					}).success(function(data){
						mainCtrl.customer = data.payload;	
					}).error(function(data){
						console.log(data);		
					});
		
			
			
			mainCtrl.addReservation = function() {

				
				$http ({
					method: 'POST',
					url: 'api/reservation/add',
					data: mainCtrl.newReservation
				}).success(function(data){
					mainCtrl.customer = data.payload;	
					mainCtrl.result = true;
					location.reload();
				}).error(function(data){
					console.log(data);		
				});
		};
		
		mainCtrl.changeReservation = function() {

				
				$http ({
					method: 'PUT',
					url: 'api/reservation/change',
					data: mainCtrl.newReservation,
					headers: {"Content-Type": "application/json;charset=utf-8"}
				}).success(function(data){
					mainCtrl.customer = data.payload;	
					location.reload();
				}).error(function(data){
					console.log(data);		
				});
		};
		
		mainCtrl.deleteReservation = function() {

			      
			      $http ({
						method: 'DELETE',
						url: 'api/reservation/delete',
						data: mainCtrl.newReservation,
						headers: {"Content-Type": "application/json;charset=utf-8"}
					}).success(function(data){
						mainCtrl.customer = data.payload;	
						location.reload();
					}).error(function(data){
						console.log(data);		
					});
			};
			    }
				
				
		 
		

		    
		   
		    
})();
