(function() {

	angular
	.module('MainModule')
	.controller('SeatingController', sController);
		
	

	
		sController.$inject = ['$http']
		function sController($http) {
			var seatingCtrl = this;
			
			/*mainCtrl.tab = 1;
		    
		    mainCtrl.selectTab = function (setTab){
		    	mainCtrl.tab = setTab;
		    };
		    mainCtrl.isSelected = function(checkTab) {
		    	return mainCtrl.tab === checkTab;
		    };*/
			
			init();
		
			function init() {

				
					$http ({
						method: 'GET',
						url: 'api/seating/all'
					}).success(function(data){
						seatingCtrl.customer = data.payload;	
			
						
					}).error(function(data){
						console.log(data);		
					});
						
				
		
			}
			/*seatingCtrl.addSeating = function($scope) {
					$http ({
					method: 'POST',
					url: 'api/seating/add',
					//data: seatingCtrl.customer,
					data:$scope.data.confirmationId,
					headers: {"Content-Type": "application/json;charset=utf-8"}
				}).success(function(data){
					custCtrl.customer = data.payload;	
					
				}).error(function(data){
					console.log($scope.data.confirmationId);		
				});
			}*/
		}
})();