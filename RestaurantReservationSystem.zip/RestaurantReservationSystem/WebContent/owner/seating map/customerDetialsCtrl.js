(function() {

	angular
	.module('MainModule')
	.controller('CustProfileController', custController);
		
		custController.$inject = ['$http','$routeParams']
		function custController($http, $routeParams) {
			var custCtrl = this;
		
					$http ({
						method: 'GET',
						url: 'api/reservation/all/' + $routeParams.confirmationId
					}).success(function(data){
					custCtrl.customer = data.payload;
					}).error(function(data){
						console.log(data);		
					});
			
			custCtrl.assign = function() {
				$http ({
					method: 'GET',
					url: 'api/seating/vacant'
				}).success(function(data,$scope){
					custCtrl.customer = data.payload;	
					console.log(custCtrl.customer);
					if((custCtrl.customer[0].status=="vacant") && (custCtrl.customer[1].status == "vacant") && (custCtrl.customer[2].status=="vacant") && (custCtrl.customer[3].status=="vacant") && (custCtrl.customer[4].status=="vacant"))
				{
						custCtrl.noVacant = false;
				}
					else {
						custCtrl.noVacant = true;
					}
					
				}).error(function(data){
					console.log(data);		
				});
			}
			
			
			custCtrl.refresh = function() {
				location.reload();
			}
			
		/*	custCtrl.addSeating = function($scope) {
				console.log('----'+JSON.stringify(custCtrl.customer));
				$http ({
					method: 'POST',
					url: 'api/seating/add',
					data: custCtrl.customer[1],
					headers: {"Content-Type": "application/json"}
				}).success(function(data){
					custCtrl.customer = data.payload;	
					
				}).error(function(data){
					console.log(data);		
				});
			}
		*/
			
			
		}
		
})();