(function() {

	angular
	.module('MainModule')
	.controller('LoginController', logController);
		

	
		logController.$inject = ['$http']
		function logController($http) {
			var loginCtrl = this;

			$http ({
				method: 'GET',
				url: 'api/authenticate/isLogin'
			}).success(function(data){
				if(data.status=='success')
				loginCtrl.isLoggedIn = true;
				else
				loginCtrl.isLoggedIn = false;
					
			}).error(function(data){
				console.log(data);		
			});
			
			
			
			
loginCtrl.login = function() {
	
					$http ({
						method: 'POST',
						url: 'api/authenticate/login',
						data: loginCtrl.auth
						
					}).success(function(data){
						if(data.status=='success')
							{
							loginCtrl.isLoggedIn = true;
							$location.path('/currReserv');
							}
						else
							{
							loginCtrl.isLoggedIn = false;
							}
						
					}).error(function(data){
						console.log(data);		
					});
			};
			
			/*loginCtrl.logout = function() {
				
				$http ({
					method: 'POST',
					url: 'api/authenticate/logout',
					data: loginCtrl.auth
					
				}).success(function(data){
					if(data.status=='success')
						{
						loginCtrl.isLoggedOut = true;
						}
					else
						{
						loginCtrl.isLoggedOut = false;
						}
					
				}).error(function(data){
					console.log(data);		
				});
		};*/
			
		}
		})();