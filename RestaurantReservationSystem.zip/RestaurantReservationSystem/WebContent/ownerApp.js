(function() {
	'use strict';
	
	var myApp = angular.module('MainModule',['ngRoute','ngMessages'])	
	myApp.config(moduleConfig);
	    
	    moduleConfig.$inject = ['$routeProvider'];
	    function moduleConfig($routeProvider) {
	      $routeProvider
	        .when('/signIn', {
	          templateUrl: 'owner/authentication/login.html',
	          controller: 'LoginController',
	          controllerAs: 'loginCtrl'
	          })
	        .when('/currReserv', {
	          templateUrl: 'owner/reservation/reserv.html',
	          controller: 'MainController',
	          controllerAs: 'mainCtrl'
	        })
	         .when('/seating', {
	          templateUrl: 'owner/seating/seating.html',
	          controller: 'SeatingController',
	          controllerAs: 'seatingCtrl'
	        })
	        .when('/profile', {
	          templateUrl: 'owner/profile/profile.html',
	         /* controller: 'MainController',
	          controllerAs: 'mainCtrl'*/
	        })
	         .when('/currReserv/:confirmationId', {
	          templateUrl: 'owner/seating map/customerDetails.html',
	          controller: 'CustProfileController',
	          controllerAs: 'custCtrl'
	        })
	       .when('/signOut', {
	         /* templateUrl: 'login.html',*/
	          controller: 'LogoutController',
	         /* controllerAs: 'loginCtrl'*/
	          })
	        .otherwise({
	          redirectTo: '/signIn'
	        });
	    }
	
	   
})();