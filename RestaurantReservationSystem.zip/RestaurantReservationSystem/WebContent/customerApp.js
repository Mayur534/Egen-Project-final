(function() {

	var myApp = angular.module('MainModule',['ngMessages'])
	myApp.controller('CcController', mController);
		
	

	
		mController.$inject = ['$http']
		function mController($http) {
			var ccCtrl = this;
			
		
				
					$http ({
						method: 'GET',
						url: 'api/reservation/all'
					}).success(function(data){
						ccCtrl.customer = data.payload;
						console.log(ccCtrl.customer);
					}).error(function(data){
						console.log(data);		
					});
					
					
					ccCtrl.addReservation = function() {

						
						$http ({
							method: 'POST',
							url: 'api/reservation/add',
							data: ccCtrl.newReservation
						}).success(function(data){
							ccCtrl.customer = data.payload;	
							ccCtrl.result = true;
							location.reload();
							
						}).error(function(data){
							console.log(data);		
						});
				};
				
				ccCtrl.changeReservation = function() {

						
						$http ({
							method: 'PUT',
							url: 'api/reservation/change',
							data: ccCtrl.newReservation,
							headers: {"Content-Type": "application/json;charset=utf-8"}
						}).success(function(data){
							ccCtrl.customer = data.payload;	
							location.reload();
						}).error(function(data){
							console.log(data);		
						});
				};
				
				ccCtrl.deleteReservation = function() {

					      
					      $http ({
								method: 'DELETE',
								url: 'api/reservation/delete',
								data: ccCtrl.newReservation,
								headers: {"Content-Type": "application/json;charset=utf-8"}
							}).success(function(data){
								ccCtrl.customer = data.payload;	
								location.reload();
							}).error(function(data){
								console.log(data);		
							});
					};
		}
		
})();