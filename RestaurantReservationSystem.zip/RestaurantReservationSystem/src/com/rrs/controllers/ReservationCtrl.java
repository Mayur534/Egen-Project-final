package com.rrs.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.rrs.dbinterfaces.ReservationInterface;
import com.rrs.exception.ExceptionResponse;
import com.rrs.exception.ExceptionThrow;
import com.rrs.fields.AuthenticationFields;
import com.rrs.fields.ReservationFields;


@Path("/reservation")
public class ReservationCtrl {

	
	
	
	@GET
	@Path("/all")
	@Produces(MediaType.APPLICATION_JSON)
	public ExceptionResponse getAll()
	{
		
		ExceptionResponse eResponse = new ExceptionResponse();
		ReservationInterface empI = new ReservationInterface();
		List<ReservationFields> rfList = null;
		try {
			rfList = empI.getAll();
			eResponse.setStatus("success");
			eResponse.setPayload(rfList);
		} catch (ExceptionThrow e) {
			e.printStackTrace();
			eResponse.setStatus(ExceptionResponse.ERROR);
			eResponse.setMsg(e.getMessage());
		}
		return eResponse;
	
	}
	
	@GET
	@Path("/all/{confirmationId}")
	@Produces(MediaType.APPLICATION_JSON)
	public ExceptionResponse getReserv(@PathParam("confirmationId") int cid)
	{
		ExceptionResponse eResponse = new ExceptionResponse();
		ReservationInterface empI = new ReservationInterface();
		ReservationFields rf = null;
		try {
		rf = empI.getReserv(cid);
		eResponse.setStatus("success");
		eResponse.setPayload(rf);
	} catch (ExceptionThrow e) {
		e.printStackTrace();
		eResponse.setStatus(ExceptionResponse.ERROR);
		eResponse.setMsg(e.getMessage());
	}
	return eResponse;
	}
	
	@POST
	@Path("/add")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public ExceptionResponse addReservation(ReservationFields rid)
	{
		ExceptionResponse eResponse = new ExceptionResponse();
		ReservationInterface empI = new ReservationInterface();
		
		try {
		rid = empI.addReservation(rid);
		eResponse.setMsg("Reservation has been successfully added to the database");
		eResponse.setPayload(rid);
	} catch (ExceptionThrow e) {
		e.printStackTrace();
		eResponse.setStatus(ExceptionResponse.ERROR);
		eResponse.setMsg(e.getMessage());
	}
	return eResponse;
	}
	
	@DELETE
	@Path("/delete")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public ExceptionResponse deleteReservation(ReservationFields rid)
	{
		System.out.println("deletion reached");
		ExceptionResponse eResponse = new ExceptionResponse();
		ReservationInterface empI = new ReservationInterface();
		ReservationFields rf = null;
		try {
		rf = empI.deleteReservation(rid);
		eResponse.setMsg("Reservation has been successfully deleted from the database");
		eResponse.setPayload(rid);
	} catch (ExceptionThrow e) {
		e.printStackTrace();
		eResponse.setStatus(ExceptionResponse.ERROR);
		eResponse.setMsg(e.getMessage());
	}
	return eResponse;
	}
	
	@PUT
	@Path("/change")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public ExceptionResponse changeReservation(ReservationFields rid)
	{
		System.out.println("change reached");
		ExceptionResponse eResponse = new ExceptionResponse();
		ReservationInterface empI = new ReservationInterface();
		ReservationFields rf = null;
		try {
		rf = empI.changeReservation(rid);
		eResponse.setMsg("Reservation has been successfully changed in the database");
		eResponse.setPayload(rid);
	} catch (ExceptionThrow e) {
		e.printStackTrace();
		eResponse.setStatus(ExceptionResponse.ERROR);
		eResponse.setMsg(e.getMessage());
	}
	return eResponse;
	}
}
