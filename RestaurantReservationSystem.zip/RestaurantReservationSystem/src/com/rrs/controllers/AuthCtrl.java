package com.rrs.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.rrs.dbinterfaces.AuthInterface;

import com.rrs.exception.ExceptionResponse;
import com.rrs.exception.ExceptionThrow;
import com.rrs.fields.AuthenticationFields;


@Path("/authenticate")
public class AuthCtrl {

	@POST
	@Path("/login")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public ExceptionResponse authenticate(AuthenticationFields aid, @Context HttpServletRequest request)
	{
	
		ExceptionResponse eResponse = new ExceptionResponse();
		AuthInterface empI = new AuthInterface();
		boolean isAuthenticated;
		try {
		isAuthenticated = empI.authenticate(aid);
		
		HttpSession session = request.getSession(true);
		
		session.setAttribute("USER", aid);
		
		if(isAuthenticated) {
			eResponse.setMsg("Authentication successful");
			eResponse.setStatus("success");
		}
		
		else {
			eResponse.setMsg("Invalid");
			eResponse.setStatus(ExceptionResponse.ERROR);
		}
			
		
	} catch (ExceptionThrow e) {
		e.printStackTrace();
		eResponse.setStatus(ExceptionResponse.ERROR);
		eResponse.setMsg(e.getMessage());
	}
	return eResponse;
	}
	
	
	/*@POST
	@Path("/logout")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public ExceptionResponse logOut(AuthenticationFields aid, @Context HttpServletRequest request)
	{
	
		ExceptionResponse eResponse = new ExceptionResponse();
		ReservationInterface empI = new ReservationInterface();
		boolean isAuthenticated;
		try {
		isAuthenticated = empI.authenticate(aid);
		
		HttpSession session = request.getSession();
		
		session.removeAttribute("USER");
		session.invalidate();
	
		if(isAuthenticated) {
			eResponse.setMsg("Logout successful");
			eResponse.setStatus("success");
		}
		
		else {
			eResponse.setMsg("Still logged in");
			eResponse.setStatus(ExceptionResponse.ERROR);
		}
			
		
	} catch (ExceptionThrow e) {
		e.printStackTrace();
		eResponse.setStatus(ExceptionResponse.ERROR);
		eResponse.setMsg(e.getMessage());
	}
	return eResponse;
	}
	*/
	
	@GET
	@Path("/isLogin")
	@Produces(MediaType.APPLICATION_JSON)
	public ExceptionResponse isLoggedIn(@Context HttpServletRequest request)
	{
	
		ExceptionResponse eResponse = new ExceptionResponse();
		
		HttpSession session = request.getSession(false);
		
		if(session != null && session.getAttribute("USER") != null) {
			eResponse.setMsg("User is logged in");
			eResponse.setStatus("success");
		}
			
		else {
			eResponse.setMsg("User is not logged in");
		eResponse.setStatus(ExceptionResponse.ERROR);
		}
	return eResponse;
	}
}
