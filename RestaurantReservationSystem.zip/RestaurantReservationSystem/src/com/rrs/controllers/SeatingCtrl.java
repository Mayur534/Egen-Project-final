package com.rrs.controllers;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


import com.rrs.dbinterfaces.SeatingInterface;
import com.rrs.exception.ExceptionResponse;
import com.rrs.exception.ExceptionThrow;

import com.rrs.fields.SeatingFields;

@Path("/seating")
public class SeatingCtrl {

	
	@GET
	@Path("/all")
	@Produces(MediaType.APPLICATION_JSON)
	public ExceptionResponse getAll()
	{
		
		ExceptionResponse eResponse = new ExceptionResponse();
		SeatingInterface empI = new SeatingInterface();
		List<SeatingFields> rfList = null;
		try {
			rfList = empI.getAll();
			eResponse.setStatus("success");
			eResponse.setPayload(rfList);
		} catch (ExceptionThrow e) {
			e.printStackTrace();
			eResponse.setStatus(ExceptionResponse.ERROR);
			eResponse.setMsg(e.getMessage());
		}
		return eResponse;
	
	}
	
	@GET
	@Path("/vacant")
	@Produces(MediaType.APPLICATION_JSON)
	public ExceptionResponse getVacant()
	{
		
		ExceptionResponse eResponse = new ExceptionResponse();
		SeatingInterface empI = new SeatingInterface();
		List<SeatingFields> rfList = null;
		try {
			rfList = empI.getVacant();
			eResponse.setStatus("success");
			eResponse.setPayload(rfList);
		} catch (ExceptionThrow e) {
			e.printStackTrace();
			eResponse.setStatus(ExceptionResponse.ERROR);
			eResponse.setMsg(e.getMessage());
		}
		return eResponse;
	
	}
	
	@POST
	@Path("/add")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public ExceptionResponse addSeating(SeatingFields sf)
	{
		System.out.println("add seating reached");
		ExceptionResponse eResponse = new ExceptionResponse();
		SeatingInterface empI = new SeatingInterface();
		
		try {
			sf = empI.addSeating(sf);
			eResponse.setStatus("success");
			eResponse.setPayload(sf);
		} catch (ExceptionThrow e) {
			e.printStackTrace();
			eResponse.setStatus(ExceptionResponse.ERROR);
			eResponse.setMsg(e.getMessage());
		}
		return eResponse;
	
	}
	
}
