package com.rrs.exception;

public class ExceptionThrow extends Exception{

	private static final long serialVersionUID = 1L;

	public ExceptionThrow(String msg) {
		super(msg);
	}
	
	public ExceptionThrow(String msg, Throwable cause) {
		super(msg, cause);
	}
}
