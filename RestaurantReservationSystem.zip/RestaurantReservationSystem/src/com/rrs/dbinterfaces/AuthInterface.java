package com.rrs.dbinterfaces;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.rrs.dbutils.RRSdbUtil;
import com.rrs.exception.ExceptionThrow;
import com.rrs.fields.AuthenticationFields;

public class AuthInterface {

	public boolean authenticate(AuthenticationFields aid) throws ExceptionThrow {
		
		Connection con = RRSdbUtil.dbConnection();
		AuthenticationFields af = new AuthenticationFields();
			PreparedStatement ps = null;
			ResultSet rs = null;
			boolean au;
			
			try {
				ps= con.prepareStatement("SELECT * FROM auth_table");
				
				rs = ps.executeQuery();
				
				while(rs.next())
				{
					
					af.setEmail(rs.getString("USERNAME"));
					af.setPassword(rs.getString("PASSWORD"));
					
					
				}
			
				au = (aid.getEmail().equals(af.getEmail())) && (aid.getPassword().equals(af.getPassword()));
				
				
			} catch (SQLException e) {
				
				e.printStackTrace();
				throw new ExceptionThrow("Error whileadding record in database");
			}
			finally {
				RRSdbUtil.closeResources(ps, rs, con);
			}
			
			return au;
		}
}
