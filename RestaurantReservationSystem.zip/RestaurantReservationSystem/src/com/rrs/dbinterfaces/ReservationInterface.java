package com.rrs.dbinterfaces;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.rrs.dbutils.RRSdbUtil;
import com.rrs.exception.ExceptionThrow;
import com.rrs.fields.AuthenticationFields;
import com.rrs.fields.ReservationFields;

public class ReservationInterface {

public List<ReservationFields> getAll() throws ExceptionThrow {
		

		List<ReservationFields> rfList = new ArrayList<ReservationFields>();
		Connection con = RRSdbUtil.dbConnection();
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			ps= con.prepareStatement("SELECT * FROM reservation_table");
			rs = ps.executeQuery();
			while(rs.next())
			{
				ReservationFields rf = new ReservationFields();
				rf.setconfirmationId(rs.getInt("CONFIRMATION_ID"));
				rf.setCustName(rs.getString("CUST_NAME"));
				rf.setPhone(rs.getString("CUST_PHONE"));
				rf.setPartySize(rs.getInt("PARTY_SIZE"));
				rf.setReservationDate(rs.getDate("RESERVATION_DATE"));
				rf.setStatus(rs.getString("STATUS"));
				
				rfList.add(rf);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
			throw new ExceptionThrow("Error while retreiving records from database");
		}
		finally {
			RRSdbUtil.closeResources(ps, rs, con);
		}
		
		return rfList;
	}

public ReservationFields getReserv(int cid) throws ExceptionThrow {
	// TODO Auto-generated method stub
	ReservationFields rf = new ReservationFields();
	Connection con = RRSdbUtil.dbConnection();
	
	PreparedStatement ps = null;
	ResultSet rs = null;
	
	try {
		ps= con.prepareStatement("SELECT * FROM reservation_table WHERE CONFIRMATION_ID=?");
		ps.setInt(1, cid);
		rs = ps.executeQuery();
		if(rs.next())
		{
			
			rf.setconfirmationId(rs.getInt("CONFIRMATION_ID"));
			rf.setCustName(rs.getString("CUST_NAME"));
			rf.setPhone(rs.getString("CUST_PHONE"));
			rf.setPartySize(rs.getInt("PARTY_SIZE"));
			rf.setReservationDate(rs.getDate("RESERVATION_DATE"));
			rf.setStatus(rs.getString("STATUS"));
		}
	} catch (SQLException e) {
		
		e.printStackTrace();
		throw new ExceptionThrow("Error while retreiving record from database");
	}
	finally {
		RRSdbUtil.closeResources(ps, rs, con);
	}
	
	return rf;
}

public ReservationFields addReservation(ReservationFields rid) throws ExceptionThrow {
	
	
	Connection con = RRSdbUtil.dbConnection();
	
	PreparedStatement ps = null;
	ResultSet rs = null;
	
	try {
		ps= con.prepareStatement("INSERT INTO reservation_table (CUST_NAME, CUST_PHONE, PARTY_SIZE, RESERVATION_DATE, STATUS) VALUES(?,?,?,?,?)", PreparedStatement.RETURN_GENERATED_KEYS);
		ps.setString(1, rid.getCustName());
		ps.setString(2, rid.getPhone());
		ps.setInt(3, rid.getPartySize());
		ps.setDate(4, rid.getReservationDate());
		ps.setString(5, "Waiting");
		
		ps.executeUpdate();
		
		rs = ps.getGeneratedKeys();
		
		while(rs.next())
		{
		rid.setconfirmationId(rs.getInt(1));	
		}
	} catch (SQLException e) {
		
		e.printStackTrace();
		throw new ExceptionThrow("Error while adding record in database");
	}
	finally {
		RRSdbUtil.closeResources(ps, rs, con);
	}
	
	return rid;
}

public ReservationFields deleteReservation(ReservationFields rid) throws ExceptionThrow {
	//ReservationFields rf = new ReservationFields();
	//System.out.println("deletion interface reached");
	//System.out.println(rid.getCustName());
	Connection con = RRSdbUtil.dbConnection();
	
	PreparedStatement ps = null;
	ResultSet rs = null;
	
	try {
		ps= con.prepareStatement("DELETE FROM reservation_table WHERE CONFIRMATION_ID=?");
		ps.setInt(1, rid.getconfirmationId());
		
		
		ps.executeUpdate();
		

	} catch (SQLException e) {
		
		e.printStackTrace();
		throw new ExceptionThrow("Error while deleting record from database");
	}
	finally {
		RRSdbUtil.closeResources(ps, rs, con);
	}
	
	return rid;
}

public ReservationFields changeReservation(ReservationFields rid) throws ExceptionThrow {

//	System.out.println(rid.getCustName());
	//System.out.println(rid.getconfirmationId());
Connection con = RRSdbUtil.dbConnection();
	
	PreparedStatement ps = null;
	ResultSet rs = null;
	
	try {
		ps= con.prepareStatement("UPDATE reservation_table SET RESERVATION_DATE=?, PARTY_SIZE=? WHERE CONFIRMATION_ID=?");
		ps.setDate(1, rid.getReservationDate());
		ps.setInt(2, rid.getPartySize());
		ps.setInt(3, rid.getconfirmationId());
		
		
		ps.executeUpdate();
		
		
	} catch (SQLException e) {
		
		e.printStackTrace();
		throw new ExceptionThrow("Error while changing record in database");
	}
	finally {
		RRSdbUtil.closeResources(ps, rs, con);
	}
	
	return rid;
}



}
