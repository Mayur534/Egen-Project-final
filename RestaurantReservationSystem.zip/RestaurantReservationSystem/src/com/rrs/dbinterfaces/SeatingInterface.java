package com.rrs.dbinterfaces;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.rrs.dbutils.RRSdbUtil;
import com.rrs.exception.ExceptionThrow;

import com.rrs.fields.SeatingFields;

public class SeatingInterface {

	public List<SeatingFields> getAll() throws ExceptionThrow {
		System.out.println("all interface reached");
		List<SeatingFields> sfList = new ArrayList<SeatingFields>();
		
		Connection con = RRSdbUtil.dbConnection();
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			ps= con.prepareStatement("SELECT * FROM seating_table");
		
			rs = ps.executeQuery();
			
			while(rs.next())
			{
				SeatingFields sf = new SeatingFields();
				
				sf.setTableId(rs.getInt("TABLE_ID"));
				sf.setStatus(rs.getString("TABLE_STATUS"));
				sf.setConfirmationId(rs.getInt("CONFIRMATION_ID"));
				
				
				sfList.add(sf);
				
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			throw new ExceptionThrow("Error while retreiving record from database");
		}
		finally {
			RRSdbUtil.closeResources(ps, rs, con);
		}
		
		return sfList;
	}

	public List<SeatingFields> getVacant() throws ExceptionThrow {
		System.out.println("vacant interface reached");
List<SeatingFields> sfList = new ArrayList<SeatingFields>();
		
		Connection con = RRSdbUtil.dbConnection();
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			ps= con.prepareStatement("SELECT * FROM seating_table");
		
			rs = ps.executeQuery();
			while(rs.next())
			{
				SeatingFields sf = new SeatingFields();
	
				sf.setTableId(rs.getInt("TABLE_ID"));
				sf.setStatus(rs.getString("TABLE_STATUS"));
				
				sf.setConfirmationId(rs.getInt("CONFIRMATION_ID"));
				
			/*if(sf.getStatus().equals("vacant"))
		{
				sfList.add(sf);
		}	*/	
		sfList.add(sf);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
			throw new ExceptionThrow("Error while retreiving record from database");
		}
		finally {
			RRSdbUtil.closeResources(ps, rs, con);
		}
		
		return sfList;
	}

	public SeatingFields addSeating(SeatingFields sf) throws ExceptionThrow {
		System.out.println("add seating interface reached");
		Connection con = RRSdbUtil.dbConnection();
		System.out.println(sf.getStatus());
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			ps= con.prepareStatement("INSERT INTO seating_table (TABLE_STATUS, CONFIRMATION_ID) VALUES(?, ?)", PreparedStatement.RETURN_GENERATED_KEYS);
			
			ps.setInt(2, sf.getConfirmationId());
			
			
			ps.executeUpdate();
			
			rs = ps.getGeneratedKeys();
			
			while(rs.next())
			{
			sf.setConfirmationId(rs.getInt(1));	
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
			throw new ExceptionThrow("Error whileadding record in database");
		}
		finally {
			RRSdbUtil.closeResources(ps, rs, con);
		}
		
		return sf;
	}

}
