package com.rrs.fields;

import java.sql.Date;

public class ReservationFields {

	private int confirmationId;
	private String custName;
	private String phone;
	private Date reservationDate;
	private String status;
	private int partySize;
	
	public int getconfirmationId() {
		return confirmationId;
	}
	public void setconfirmationId(int confirmationId) {
		this.confirmationId = confirmationId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public Date getReservationDate() {
		return reservationDate;
	}
	public void setReservationDate(Date reservationDate) {
		this.reservationDate = reservationDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getPartySize() {
		return partySize;
	}
	public void setPartySize(int partySize) {
		this.partySize = partySize;
	}
	
	
}
