package com.rrs.config;

import javax.ws.rs.ApplicationPath;

import org.glassfish.jersey.server.ResourceConfig;

@ApplicationPath("/api")
public class Config extends ResourceConfig {

	public Config()
	{
		packages("com.rrs.controllers");
	}
}
